export default {
  itemsLimit: 1000,
}
