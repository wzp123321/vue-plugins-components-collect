module.exports = {
  presets: [
    [require('@babel/preset-env'), { modules: false }],
  ],
}
