# vue-virtual-scroller-demos

> Demos for vue-virtual-scroller

## Build Setup

``` bash
# install dependencies
yarn install

# serve with hot reload at localhost:8080
yarn run dev

# build for production with minification
yarn run build
```
